import firestore from '@react-native-firebase/firestore';
import React, { useEffect, useState } from 'react';
import {
  Alert,
  FlatList,
  Image,
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View
} from 'react-native';

import moment from 'moment';
import { Icon } from 'react-native-elements';
import { useSelector } from 'react-redux';
import errorLog, { defaultAlert } from '../Constants/errorLog';
import { getPartOfList } from '../backend/paginatedList';
import Header from '../components/header';
import PostCard from '../components/postCard';
import { mScale, scale, vScale } from '../configs/size';
import { renderInitials } from './activism/ActivismDetails';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';
import { Item } from 'react-native-paper/lib/typescript/components/Drawer/Drawer';
import Utility, { DEVICE_WIDTH } from '../utils/Utility';
import AppModalView from '../components/appModal/AppModalView';
import UserInfoService from '../utils/UserInfoService';
import { firebaseDbObject } from '../utils/FirebseDbObject';
import { addReply } from '../components/commentsReplies/Reply';
import RoundImage from '../components/roundImage';

const SinglePost = ({ navigation, route }) => {

  // return false;
  const id = route.params?.postData?.data?.id;
  const [comments, setComments] = useState<any[]>([]);
  const [commensq, setCommensq] = useState<any[]>([]);
  const [lastDoc, setLastDoc] = useState();
  const [input, setInput] = useState('');
  const [kHeight, setkHeight] = useState(0);
  const [showModal, setShowModal] = useState(false);
  const [editableComment, setEditableComment] = useState<any>(null);
  const [replyingTo, setReplyingTo] = useState(null);  // Track which comment/reply is being replied to
  const [replyText, setReplyText] = useState("");  // Store reply text
  const [replyingToMap, setReplyingToMap] = useState({});
  const [replyTextMap, setReplyTextMap] = useState({});
  const [replyingToReplyId, setReplyingToReplyId] = useState(null); // For nested replies
  const userProfile = useSelector((state) => state.user.userProfile);

  useEffect(() => {
    console.log('COMMME')
    
console.log(id)


  }, []);


  const postViewsUpdate = async () => {
    const postId = route.params?.postData?.data?.id;
    const userId = route.params?.userId;
    const ref = firestore().collection('Posts').doc(postId);
    const viewRef = ref.collection('Views').doc(userId);
    viewRef.get().then((snap) => {
      if (!snap.exists) {
        const bodyviews = {
          id: userId,
        };
        const batch = firestore().batch();
        batch.set(viewRef, bodyviews);
        batch.update(ref, { viewsCount: firestore.FieldValue.increment(1) });
        batch.commit();
      }
    });
  }

  useEffect(() => {

    const showSubscription = Keyboard.addListener(
      'keyboardWillShow',
      (event) => {
        const keyboardHeight = event.endCoordinates.height;
        setkHeight(keyboardHeight);
      },
    );

    const hideSubscription = Keyboard.addListener('keyboardWillHide', () => {
      setkHeight(0);
    });

    return () => {
      showSubscription.remove();
      hideSubscription.remove();
    };
  }, []);

  const getComments = async () => {
    console.log('kajaj')
    console.log(id)
    try {
      const commentsRef = firestore()
        .collection('Posts')
        .doc(id)
        .collection('Comments')
        .orderBy('createdAt', 'desc')
        .limit(40);
  
      const commentsSnapshot = await commentsRef.get();
      setLastDoc(commentsSnapshot.docs[commentsSnapshot.docs.length - 1]);
      const blockedCommentsRef = firestore()
        .collection('Users')
        .doc(UserInfoService.getUserId())
        .collection('BlockedComments');
  
      const blockedCommentsSnapshot = await blockedCommentsRef.get();
      const blockedCommentIds = new Set(
        blockedCommentsSnapshot.docs.map((doc) => doc.id)
      );
  
      const commentsWithReplies = await Promise.all(
        commentsSnapshot.docs.map(async (doc) => {
          if (blockedCommentIds.has(doc.id)) return null;
  
          const replies = await fetchRepliesRecursively(id, doc.id);
  
          return {
            ...doc.data(),
            id: doc.id,
            userId: doc.data().id,
            replies,
          };
        })
      );
  
      setComments(commentsWithReplies.filter(Boolean));
    } catch (error) {
      console.error('Error fetching comments:', error);
    }
  };

  const loadMoreComments = async () => {
    if (!lastDoc) return;
  
    const commentsRef = firestore()
      .collection('Posts')
      .doc(id)
      .collection('Comments')
      .orderBy('createdAt', 'desc')
      .startAfter(lastDoc)
      .limit(40);
  
    const snapshot = await commentsRef.get();
  
    // (repeat processing logic here for replies etc.)
  };
  

  const getMoreComments = async () => {
    // if (!lastDoc) {
    //   return;
    // }
    // try {
    //   const ref = firestore()
    //     .collection('Posts')
    //     .doc(id)
    //     .collection('Comments')
    //     .limit(15)
    //     .after(lastDoc);
    //   const result = await getPartOfList({ ref, limitNum: 15 });

    //   setComments([...comments, ...result.list]);
    //   setLastDoc(result.lastDoc);
    // } catch (error) {
    //   defaultAlert();
    //   errorLog('while getting top trending posts', error);
    // }
  };

  useEffect(() => {
    getComments();
  }, [commensq]);

  const blockComment = (item) => {
    Utility.showMessageWithActionCancel(async () => {
      try {
        // Add to user's blocked comments
        const blockedCommentRef = firebaseDbObject
          .collection('Users')
          .doc(UserInfoService.getUserId())
          .collection('BlockedComments')
          .doc(item.id);

        await blockedCommentRef.set({ postId: id });
        // Increment blocked count on the comment document
        const commentRef = firebaseDbObject
          .collection('Posts')
          .doc(id)
          .collection('Comments')
          .doc(item.docId);

        await commentRef.update({
          blockedCount: firestore.FieldValue.increment(1),
        });
        getComments();
        console.log('Comment blocked successfully.');
      } catch (error) {
        Alert.alert('Error', 'Failed to block the comment. Please try again later.');
      }

    }, () => { }, 'Are you sure you want to block this comment', 'Block comment')
  }

  const deleteComment = (item) => {
    Utility.showMessageWithActionCancel(async () => {
      try {
        firestore()
          .collection('Posts')
          .doc(id)
          .collection('Comments')
          .doc(item.id)
          .delete().then(() => {
            getComments();
          });

        firestore()
          .collection('Posts')
          .doc(id).update({
            totalComments: firestore.FieldValue.increment(-1)
          });

        const usersRef = firebaseDbObject.collection('Users');
        const blockedUsersSnapshot = await usersRef
          .where('BlockedComments', 'array-contains', item.id)
          .get();

        // Step 3: Iterate over each user who has blocked the comment
        const promises = blockedUsersSnapshot.docs.map(async (userDoc) => {
          const userId = userDoc.id;
          const blockedCommentRef = firebaseDbObject.collection('Users').doc(userId).collection('BlockedComments').doc(item.id);

          // Step 4: Remove the comment from this user's blocked comments list
          await blockedCommentRef.delete();
          
        });

        // Wait for all promises to resolve
        await Promise.all(promises);

      } catch (error) {
        Alert.alert('Error', 'Failed to delete the comment. Please try again later.');
      }

    }, () => { }, 'Are you sure you want to delete this comment', 'Delete comment')
  }

  const editComment = () => {
    try {
      firestore()
        .collection('Posts')
        .doc(id)
        .collection('Comments')
        .doc(editableComment.id)
        .update({
          content: editableComment.content,
          lastEdited: firestore.Timestamp.now()
        }).then(() => {
          setEditableComment(null);
          getComments();
        })

    } catch (error) {
      Alert.alert('Error', 'Failed to edit the post. Please try again later.');
    }
  }

  const publishComment = async () => {
    if (!input || input == '') {
      return;
    }
    try {
      const batch = firestore().batch();
      const postRef = firestore().collection('Posts').doc(id);
      const commentsRef = postRef.collection('Comments').doc();

      const body = {
        content: input,
        id: userProfile.userId,
        profileUrl: userProfile.profileUrl || null,
        displayName: userProfile.displayName,
        createdAt: firestore.Timestamp.now(),
        blockedCount: 0
      };

      setInput('');
      setCommensq((prev) => [...prev, body]);
      batch.update(postRef, {
        activityCount: firestore.FieldValue.increment(1),
        totalComments: firestore.FieldValue.increment(1),
      });
      batch.set(commentsRef, body);
      await batch.commit();


      setTimeout(async () => {
        if (route.params?.postData?.data?.user != userProfile.userId) {
          const refNoti = firestore().collection('Users').doc(route.params?.postData?.data?.user);
          const notificationRef = refNoti.collection('Notification').doc();
          const batchInner = firestore().batch();
          batchInner.set(notificationRef, {
            id: notificationRef.id,
            type: 'COMMENT_POST',
            displayName: userProfile.displayName,
            profileUrl: userProfile.profileUrl || null,
            senderId: userProfile.userId,
            text: userProfile.displayName + ' commented on your post.',
            postId: id,
            date: new Date()
          });
          await batchInner.commit();
        }

      }, 500);
      route.params?.commentCountIncrement &&
        route.params?.commentCountIncrement();

    } catch (error) {
      defaultAlert();
      errorLog('commenting', error);
    }
  };

  const fetchRepliesRecursively: any = async (postId, commentId) => {
    const repliesRef = firestore()
      .collection('Posts')
      .doc(postId)
      .collection('Comments')
      .doc(commentId)
      .collection('Replies')
      .orderBy('createdAt', 'asc');
  
    const repliesSnapshot = await repliesRef.get();
  
    const replies = await Promise.all(repliesSnapshot.docs.map(async (doc) => {
      const subReplies = await fetchRepliesRecursively(postId, doc.id); // 👈 recursive call
      return {
        ...doc.data(),
        id: doc.id,
        userId: doc.data().id,
        replies: subReplies,
      };
    }));
  
    return replies;
  };

  const renderReply = (reply, parentId) => {
    const isReplyingToThis = replyingTo === reply.id;
  
    return (
      <View key={reply.id} style={{ marginLeft: 20, marginTop: 10 }}>
        <View style={{ borderLeftWidth: 1, paddingLeft: 10, borderColor:'rgba(0, 0, 0, 0.2)' }}>
        <View style={{flexDirection: 'row', alignItems: 'center', marginBottom: 5}}>
          <RoundImage
            userId={reply.userId}
            imageUrl={ reply.profileUrl}
            displayName={reply.displayName}
            size={30}
          />
          <View>
           <Text style={{ fontWeight: 'bold', marginLeft: 6, flex: 1 }}>{reply.displayName}</Text>
           <Text style={{ fontSize: 10, color: 'gray', marginLeft: 6, flex: 1 }}>
            {moment(reply.createdAt.toDate()).fromNow()}
          </Text>
          </View>
          </View>
         
          <Text style={{marginHorizontal: 10, flex: 1}}>{reply.content}</Text>
          
  
          <TouchableOpacity
            onPress={() => setReplyingTo(isReplyingToThis ? null : reply.id)}
            style={{ marginTop: 5 }}
          >
            <Text style={{ color: 'blue', fontSize: 12, fontWeight: 'bold' }}>Reply</Text>
          </TouchableOpacity>
  
          {isReplyingToThis && (
            <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 10 }}>
              <TextInput
                style={{
                  flex: 1,
                  borderWidth: 1,
                  borderColor: '#ccc',
                  borderRadius: 5,
                  padding: 5,
                }}
                placeholder="Write a reply..."
                value={replyText}
                onChangeText={setReplyText}
              />
              <TouchableOpacity
                onPress={() => {
                  addReply(id, reply.id, replyText, userProfile, getComments);
                  setReplyingTo(null);
                  setReplyText('');
                }}
                style={{ marginLeft: 10, padding: 5 }}
              >
                <Text style={{ color: 'green' }}>Send</Text>
              </TouchableOpacity>
            </View>
          )}
  
          {/* Render nested replies */}
          {reply.replies && reply.replies.length > 0 && (
            reply.replies.map((subReply) => renderReply(subReply, reply.id))
          )}
        </View>
      </View>
    );
  };

  const renderComment = ({ item }) => {
    console.log('commnete')
    console.log(item)
    const handleReplyPress = (commentId) => {
      setReplyingToMap(prev => ({
        ...prev,
        [commentId]: !prev[commentId]
      }));
    };
  
    const handleReplySend = async (parentCommentId) => {
      const replyText = replyTextMap[parentCommentId];
      if (!replyText) return;
  
      await addReply(id, parentCommentId, replyText, userProfile, getComments);
      setReplyTextMap(prev => ({ ...prev, [parentCommentId]: '' }));
      setReplyingToMap(prev => ({ ...prev, [parentCommentId]: false }));
    };
  
    return (
      <View style={{ margin: 10, width: DEVICE_WIDTH - 20 }}>
        {/* Main Comment */}
        <View style={{ backgroundColor: '#ffffff', borderRadius: 10, padding: 10 }}>
          <View style={{flexDirection: 'row', alignItems: 'center', marginBottom: 5}}>
          <RoundImage
            userId={item.userId}
            imageUrl={ item.profileUrl}
            displayName={item.displayName}
            size={30}
          />
          <View>
          <Text style={{ fontWeight: 'bold', marginLeft: 10 }}>{item.displayName}</Text>
          <Text style={{ fontSize: 10, color: 'gray', marginLeft: 10  }}>{moment(item.createdAt.toDate()).fromNow()}</Text>
  
          </View>
          </View>
          <Text style={{marginHorizontal: 10, flex: 1}}>{item.content}</Text>
          
          {/* Reply Button */}
          <TouchableOpacity onPress={() => handleReplyPress(item.id)}>
            <Text style={{ color: 'blue', fontSize: 12, fontWeight: 'bold' }}>Reply</Text>
          </TouchableOpacity>
  
          {/* Reply Input */}
          {replyingToMap[item.id] && (
            <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 5 }}>
              <TextInput
                value={replyTextMap[item.id] || ''}
                onChangeText={(text) =>
                  setReplyTextMap(prev => ({ ...prev, [item.id]: text }))
                }
                placeholder="Write a reply..."
                style={{ borderWidth: 1, borderColor: '#ccc', flex: 1, borderRadius: 5, padding: 5 }}
              />
              <TouchableOpacity onPress={() => handleReplySend(item.id)} style={{ marginLeft: 5 }}>
                <Text style={{ color: 'green' }}>Send</Text>
              </TouchableOpacity>
            </View>
          )}
  
          {/* Replies */}
          {item.replies && item.replies.length > 0 && (
  <View style={{ marginLeft: 20, marginTop: 10 }}>
    {item.replies.map((reply) => renderReply(reply, item.id))}
  </View>
)}
        </View>
      </View>
    );
  };
  return (
    <KeyboardAvoidingView
    style={{flex: 1, backgroundColor: '#fff'}}
    behavior={Platform.OS === "ios" ? "padding" : "height"}
  >
    <View style={{ flex: 1 }}>
      <Header navigation={navigation} otherProfile={true} />
      <View style={{ flex: 1 }}>
        <FlatList
          ListHeaderComponent={
            <PostCard
              {...route.params.postData}
              hideCommentBtn={true}
              carousel={true}
              navigation={navigation}
              isAdmin={route.params.isAdmin}
              goBack={() => navigation.goBack()}
            />
          }
          extraData={comments}
          data={comments}
          renderItem={renderComment}
          keyExtractor={(item) => item.id}
          onEndReached={loadMoreComments}
        />
      </View>
      <View
        style={{
          marginVertical: 30,
          flexDirection: 'row',
          alignItems: 'center',
          alignSelf: 'center',
          borderColor: '#1e2348',
          borderWidth: 1,
          borderRadius: mScale(15),
          paddingHorizontal: scale(10),
          backgroundColor: '#ffffff',
          height: vScale(40),
        }}>
        <TextInput
        returnKeyType='done'
        returnKeyLabel='Done'
          value={input}
          onChangeText={setInput}
          placeholder="Add a comment ..."
          style={{ width: scale(300) }}
        />
        <TouchableOpacity
          style={{
            height: scale(30),
            width: scale(30),
            borderRadius: scale(15),
            backgroundColor: 'green',
            justifyContent: 'center',
            alignItems: 'center',
          }}
          
          onPress={publishComment}>
          <Icon
            name="caret-forward"
            type="ionicon"
            size={vScale(22)}
            color="white"
          />
        </TouchableOpacity>
      </View>
      {
        editableComment ?
          <AppModalView
            visible={true}
            customStyle={{ opacity: 0.9 }}
          >
            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'rgb(0, 0, 0, 0.9)' }}>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  alignSelf: 'center',
                  borderColor: '#1e2348',
                  borderWidth: 1,
                  borderRadius: mScale(15),
                  paddingHorizontal: scale(10),
                  backgroundColor: '#ffffff',
                  height: vScale(40),
                }}>
                <TextInput
                  value={editableComment.content}
                  onChangeText={(value) => setEditableComment({ ...editableComment, content: value })}
                  placeholder="Your thoughts ..."
                  style={{ width: scale(300) }}
                />
                <TouchableOpacity
                  style={{
                    height: scale(30),
                    width: scale(30),
                    borderRadius: scale(15),
                    backgroundColor: 'green',
                    justifyContent: 'center',
                    alignItems: 'center',
                  }}
                  onPress={editComment}>
                  <Icon
                    name="caret-forward"
                    type="ionicon"
                    size={vScale(22)}
                    color="white"
                  />
                </TouchableOpacity>
              </View>

              <TouchableOpacity
                onPress={() => {
                  setEditableComment(null);
                }}
                style={{ borderRadius: 20, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center', marginTop: 20, paddingHorizontal: 40, paddingVertical: 15 }}>
                <Text style={{ fontWeight: '700', color: '#000' }}>
                  Cancel
                </Text>
              </TouchableOpacity>

            </View>
          </AppModalView>
          :
          null
      }

    </View>
    </KeyboardAvoidingView>
  );
};

export default SinglePost;


const style = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bgImage: {
    height: hp(100),
    resizeMode: 'contain',
    width: '100%',
    alignItems: 'center',
    //  opacity:.3
  },
  description: {
    margin: 10,
    fontSize: 12,
  },
  iconRight: { marginRight: 20 },
  accountText: { fontSize: 18, fontWeight: 'bold' },
  accountsCategory: { margin: 10 },
  categoryContainer: {
    borderBottomColor: 'silver',
    borderBottomWidth: 2,
    width: wp(85),
    marginTop: hp(5),
  },
  listCont: {
    backgroundColor: 'transparent',
    width: wp(89),
    padding: 4,
    margin: 0,
  },
  inputCont: {
    borderColor: '#eee',
    borderWidth: 1,
    padding: hp(1),
    borderRadius: 10,
    maxHeight: hp(18),
    minHeight: hp(12),
    marginTop: 10
  },
  errorStyle: { height: 0 },
  buttons: {
    backgroundColor: '#1b224d',
    width: wp(30),
    height: 40,
    margin: 5,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 20,
  },
  buttonText: { color: '#fff', fontWeight: 'bold' },
  cardFooter: {
    height: hp(5),
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  cardFooterInner: { flexDirection: 'row', alignItems: 'center' },
  cardFooterInnerText: { fontSize: 12, color: '#17234e', marginLeft: 5 },
  shareContainer: {
    width: wp(95),
    minHeight: hp(65),
    backgroundColor: '#fff',
    borderRadius: wp(3),
    paddingTop: hp(3),
  },
  avatar: {
    height: hp(5),
    width: hp(5),
    borderRadius: hp(5),
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#d9d9d9',
    padding: 0,
    margin: 0,
  },
  link: {
    fontSize: 16,
    fontWeight: '400',
    backgroundColor: 'rgba(36, 77, 201, 0.05)',
    color: '#244dc9',
  },
  modalButton: {
    height: 40, width: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#ddd',
    borderRadius: 10,
    marginBottom: 15
  },
  modalText: {
    fontSize: 14,
    fontWeight: '500'
  }
});
